
jQuery(document).ready(function(){

    jQuery('#the-list').on('click', '.editinline', function(){
    
        inlineEditPost.revert();
    
        var post_ids = jQuery(this).closest('tr').attr('id');
        var post_id = post_ids.replace("post-", "");

        var color_variations_can_show_inline = jQuery('#color_variations_can_show_inline_' + post_id).find("#color_variations_can_show").text();
        var ral_color_variations_inline = jQuery('#ral_color_variations_inline_' + post_id).find("#ral_color_variations").text();
        var ncs_color_variations_inline = jQuery('#ncs_color_variations_inline_' + post_id).find("#ncs_color_variations").text();
        var beckers_farver_color_variations_inline = jQuery('#beckers_farver_color_variations_inline_' + post_id).find("#beckers_farver_color_variations").text();
        var beck_jorgensen_color_variations_inline = jQuery('#beck_jorgensen_color_variations_inline_' + post_id).find("#beck_jorgensen_color_variations").text();
        var _wpm_gtin_code_inline = jQuery('#_wpm_gtin_code_inline_' + post_id).find("#_wpm_gtin_code").text();
        jQuery('input[name="color_variations_can_show"]', '.inline-edit-row').val(color_variations_can_show_inline);
        jQuery('input[name="ral_color_variations"]', '.inline-edit-row').val(ral_color_variations_inline);
        jQuery('input[name="ncs_color_variations"]', '.inline-edit-row').val(ncs_color_variations_inline);
        jQuery('input[name="beckers_farver_color_variations"]', '.inline-edit-row').val(beckers_farver_color_variations_inline);
        jQuery('input[name="beck_jorgensen_color_variations"]', '.inline-edit-row').val(beck_jorgensen_color_variations_inline);
        jQuery('input[name="_wpm_gtin_code"]', '.inline-edit-row').val(_wpm_gtin_code_inline);

        if( color_variations_can_show_inline == '1' ){
            jQuery('input[name="color_variations_can_show"]', '.inline-edit-row').prop('checked', true );
        }else{
            jQuery('input[name="color_variations_can_show"]', '.inline-edit-row').prop('checked', false );
        }
        if( ral_color_variations_inline == '1' ){
            jQuery('input[name="ral_color_variations"]', '.inline-edit-row').prop('checked', true );
        }else{
            jQuery('input[name="ral_color_variations"]', '.inline-edit-row').prop('checked', false );
        }
        if( ncs_color_variations_inline == '1' ){
            jQuery('input[name="ncs_color_variations"]', '.inline-edit-row').prop('checked', true );
        }else{
            jQuery('input[name="ncs_color_variations"]', '.inline-edit-row').prop('checked', false );
        }
        if( beckers_farver_color_variations_inline == '1' ){
            jQuery('input[name="beckers_farver_color_variations"]', '.inline-edit-row').prop('checked', true );
        }else{
            jQuery('input[name="beckers_farver_color_variations"]', '.inline-edit-row').prop('checked', false );
        }
        if( beck_jorgensen_color_variations_inline == '1' ){
            jQuery('input[name="beck_jorgensen_color_variations"]', '.inline-edit-row').prop('checked', true );
        }else{
            jQuery('input[name="beck_jorgensen_color_variations"]', '.inline-edit-row').prop('checked', false );
        }

    });
    jQuery("input#color_variations_can_show").click(function(){
        var post_id = jQuery(this).closest('tr').attr('id');
        post_id = post_id.replace("edit-", "");

        if(jQuery(this).prop('checked')) {
            jQuery('input[name="color_variations_can_show"]', '.inline-edit-row').val(1);
            jQuery(this).prop('checked', true );
            jQuery('#color_variations_can_show_inline_' + post_id).find("#color_variations_can_show").text(1);
        } else {
            jQuery('input[name="color_variations_can_show"]', '.inline-edit-row').val(0);
            jQuery(this).prop('checked', false );
            jQuery('#color_variations_can_show_inline_' + post_id).find("#color_variations_can_show").text(0);
        }
    });
    jQuery("input#ral_color_variations").click(function(){
        var post_id = jQuery(this).closest('tr').attr('id');
        post_id = post_id.replace("edit-", "");

        if(jQuery(this).prop('checked')) {
            jQuery('input[name="ral_color_variations"]', '.inline-edit-row').val(1);
            jQuery(this).prop('checked', true );
            jQuery('#ral_color_variations_inline_' + post_id).find("#ral_color_variations").text(1);
        } else {
            jQuery('input[name="ral_color_variations"]', '.inline-edit-row').val(0);
            jQuery(this).prop('checked', false );
            jQuery('#ral_color_variations_inline_' + post_id).find("#ral_color_variations").text(0);
        }
    });
    jQuery("input#ncs_color_variations").click(function(){
        var post_id = jQuery(this).closest('tr').attr('id');
        post_id = post_id.replace("edit-", "");

        if(jQuery(this).prop('checked')) {
            jQuery('input[name="ncs_color_variations"]', '.inline-edit-row').val(1);
            jQuery(this).prop('checked', true );
            jQuery('#ncs_color_variations_inline_' + post_id).find("#ncs_color_variations").text(1);
        } else {
            jQuery('input[name="ncs_color_variations"]', '.inline-edit-row').val(0);
            jQuery(this).prop('checked', false );
            jQuery('#ncs_color_variations_inline_' + post_id).find("#ncs_color_variations").text(0);
        }
    });
    jQuery("input#beckers_farver_color_variations").click(function(){
        var post_id = jQuery(this).closest('tr').attr('id');
        post_id = post_id.replace("edit-", "");

        if(jQuery(this).prop('checked')) {
            jQuery('input[name="beckers_farver_color_variations"]', '.inline-edit-row').val(1);
            jQuery(this).prop('checked', true );
            jQuery('#beckers_farver_color_variations_inline_' + post_id).find("#beckers_farver_color_variations").text(1);
        } else {
            jQuery('input[name="beckers_farver_color_variations"]', '.inline-edit-row').val(0);
            jQuery(this).prop('checked', false );
            jQuery('#beckers_farver_color_variations_inline_' + post_id).find("#beckers_farver_color_variations").text(0);
        }
    });
    jQuery("input#beck_jorgensen_color_variations").click(function(){
        var post_id = jQuery(this).closest('tr').attr('id');
        post_id = post_id.replace("edit-", "");

        if(jQuery(this).prop('checked')) {
            jQuery('input[name="beck_jorgensen_color_variations"]', '.inline-edit-row').val(1);
            jQuery(this).prop('checked', true );
            jQuery('#beck_jorgensen_color_variations_inline_' + post_id).find("#beck_jorgensen_color_variations").text(1);
        } else {
            jQuery('input[name="beck_jorgensen_color_variations"]', '.inline-edit-row').val(0);
            jQuery(this).prop('checked', false );
            jQuery('#beck_jorgensen_color_variations_inline_' + post_id).find("#beck_jorgensen_color_variations").text(0);
        }
    });

});