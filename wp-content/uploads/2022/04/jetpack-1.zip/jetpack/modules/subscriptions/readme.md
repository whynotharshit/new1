## Assets for Subscriptions

### subscriptions.css

CSS required to render the subscription widget

### views.php

This file handles the registration of various subscriptions
views, i.e. a widget and a block for the post editor.

This file is shared with wordpress.com
