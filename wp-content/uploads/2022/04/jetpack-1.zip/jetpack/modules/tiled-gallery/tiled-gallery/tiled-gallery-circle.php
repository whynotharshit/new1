<?php
require_once dirname( __FILE__ ) . '/tiled-gallery-square.php';

class Jetpack_Tiled_Gallery_Layout_Circle extends Jetpack_Tiled_Gallery_Layout_Square {
	protected $type = 'circle';
}


