<?php
/**
 * The Jetpack Connection Interface file.
 * No longer used.
 *
 * @package automattic/jetpack-connection
 */

namespace Automattic\Jetpack\Connection;

/**
 * This interface is no longer used and is now deprecated.
 *
 * @deprecated since jetpack 7.8
 */
interface Manager_Interface {
}
