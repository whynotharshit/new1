function openTab(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

colorvariationsallcolor = document.getElementsByClassName("color-variations-all-color");
for (i = 1; i < colorvariationsallcolor.length; i++) {
  colorvariationsallcolor[i].style.display = "none";
}


jQuery(document).ready(function(){
    jQuery("#colorSearch").on("keyup", function() {
      var value = jQuery(this).val().toLowerCase();
      jQuery("div.color-variations-coloritem").filter(function() {
        jQuery(this).toggle(jQuery(this).text().toLowerCase().indexOf(value) > -1)
      });
    });


    jQuery('.Select_color_collection').change(function() {
      if( jQuery(this).is(":checked") ){
        var conceptName = jQuery(this).val();
    }
      //var conceptName = $('.Select_color_collection').find(":selected").text();
      console.log('conceptName: ' + conceptName);

      if( conceptName == 'ncs-colors' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".ncs_color").attr("style", "display:block");

        var colorpick = 'Hvid';
        var colorcode = '#FFFFFF';

        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
        jQuery('.select-mixing-color').data('color', 'ncs-colors');
      }else if( conceptName == 'ral-colors' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".ral_color").attr("style", "display:block");

        var colorpick = 'Hvid';
        var colorcode = '#FFFFFF';

        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
        jQuery('.select-mixing-color').data('color', 'ral-colors');
      }else if( conceptName == 'beckers_farver' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".beckers_farver_color_values").attr("style", "display:block");
        
        var colorpick = 'White';
        var colorcode = '#FFFFFF';

        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
        jQuery('.select-mixing-color').data('color', 'beckers_farver');
      }else if( conceptName == 'beck_&_jørgensen_farver' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".beck_jorgensen_color_values").attr("style", "display:block");
        
        var colorpick = 'White';
        var colorcode = '#FFFFFF';

        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
        jQuery('.select-mixing-color').data('color', 'beck_&_jørgensen_farver');
      }

    });


      jQuery(".color-variations-coloritem").click(function(){
        var colorpick = jQuery(this).find('div.color-variations-colorpick').data('colornamefiltered');
        var colorcode = jQuery(this).find('div.color-variations-colorpick').data('colorcode');
        jQuery('input#color_variations_customcolor').val(colorpick);
        //document.getElementById( 'myModal' ).style.display = 'none';
        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show.show").attr("style", "background-color:"+colorcode+";display:block");

        jQuery('.color-variations-colorchild-block').removeClass("color-variations-border");
        jQuery(this).find('div.color-variations-colorchild-block').addClass("color-variations-border");

        jQuery('.confirm-mixing-color').attr('data-colorCode', colorcode);
        jQuery('.confirm-mixing-color').attr('data-colorName', colorpick);

        document.getElementById( 'confirm_mixing_color' ).style.display = 'block';
      });

      var state = false;
      jQuery(".confirm-mixing-color").click(function(){
        var colorpick = jQuery(this).attr("data-colorName");
        var colorcode = jQuery(this).attr("data-colorCode");
        
        jQuery('.selected-color-description').val(colorpick);
        jQuery(".selected-color.show").attr("style", "background-color:"+colorcode+";display:block");
        document.getElementById( 'myModal' ).style.display = 'none';

        jQuery('.select-mixing-color').attr('data-color_code', colorcode);
        jQuery('.select-mixing-color').attr('data-color_name', colorpick);

      });


jQuery(document.body).on('click', '.select-mixing-color', function(){
// jQuery(".select-mixing-color").click(function(){
  // btn.onclick = function() {
    var clickNum = jQuery(this).data('clickNum');
    if (!clickNum) clickNum = 1;
    
    if (clickNum == 1 ){

      var conceptName = jQuery(this).data("color");
    
      if( conceptName == 'NCS-Colors' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".ncs_color").attr("style", "display:block");
    
        var colorpick = 'Hvid';
        var colorcode = '#FFFFFF';

        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
      }else if( conceptName == 'RAL-Colors' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".ral_color").attr("style", "display:block");
    
        var colorpick = 'Hvid';
        var colorcode = '#FFFFFF';
    
        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
      }else if( conceptName == 'Beckers Farver' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".beckers_farver_color_values").attr("style", "display:block");
              
        var colorpick = 'White';
        var colorcode = '#FFFFFF';
    
        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
      }else if( conceptName == 'Beck & Jørgensen Farver' ){
        jQuery(".color-variations-all-color").attr("style", "display:none");
        jQuery(".beck_jorgensen_color_values").attr("style", "display:block");
            
        var colorpick = 'White';
        var colorcode = '#FFFFFF';
    
        jQuery('.selected-color-description-show').val(colorpick);
        jQuery(".cv-slideshow-container").attr("style", "background-color:"+colorcode+";display:block");
        jQuery(".selected-color-show").attr("style", "background-color:"+colorcode+";display:block");
      }
  }
    
    jQuery(this).data('clickNum', ++clickNum);
    jQuery("#myModal").attr("style", "display:block");
  });
});


// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close-modal")[0];

// When the user clicks the button, open the modal 


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

// image slider 
var slideIndex = [1,1];
var slideId = ["cv-slides"]
showSlides(1, 0);
showSlides(1, 1);

function plusSlides(n, no) {
  showSlides(slideIndex[no] += n, no);
}

function showSlides(n, no) {
  var i;
  var x = document.getElementsByClassName(slideId[no]);
  if (n > x.length) {slideIndex[no] = 1}    
  if (n < 1) {slideIndex[no] = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex[no]-1].style.display = "block";  
}