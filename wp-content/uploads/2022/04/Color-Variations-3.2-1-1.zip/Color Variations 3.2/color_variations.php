<?php
/**
 * Plugin Name: Color Variations 3.2
 * Plugin URI: https://www.facebook.com/abdul.h.jony1/
 * Description: color variations 3.2 in woocommerce (all rall colors / NCS colors / sikkens colors).Select the color as you like.
 * Version: 3.2.2
 * Author: Abdul Hakim Jony
 * Author URI: https://www.facebook.com/abdul.h.jony1/
 * Text Domain: color_variations
 * Domain Path: /languages
 * Requires at least: 4.0
 * Tested up to: 4.8
 *
 * @package     color_variations
 * @category 	Core
 * @author 		Abdul Hakim Jony
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
include_once(ABSPATH.'wp-admin/includes/plugin.php');
define('color_variationsDIR', plugin_dir_path( __FILE__ ));
define('color_variationsURL', plugin_dir_url( __FILE__ ));

/*
* Show notice if Woocommerce aren't installed
*/
function color_variations_admin_notice(){
    echo sprintf('<div class="notice notice-warning is-dismissible">
        <p>%s</p>
    </div>', __('"Woocommerce" is required for "Color Variations 3.1" Plugin.', 'color_variations'));
}

if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
    require_once(color_variationsDIR . 'inc/class.php');
    new color_variationsClass;
}else{
    add_action('admin_notices', 'color_variations_admin_notice');
}