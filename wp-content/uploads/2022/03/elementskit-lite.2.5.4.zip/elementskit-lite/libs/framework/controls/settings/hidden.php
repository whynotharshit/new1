<input
	type="hidden"
	id="ekit-admin-option-hidden<?php echo esc_attr(self::strify($name)); ?>"
	name="<?php echo esc_attr($name); ?>"
	value="<?php echo esc_attr($value); ?>" />
