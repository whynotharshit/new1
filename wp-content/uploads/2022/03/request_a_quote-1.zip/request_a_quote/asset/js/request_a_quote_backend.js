jQuery(document).ready(function($){
    if(jQuery('.jquerydatatable').length){
        jQuery('.jquerydatatable').DataTable();
    }
});