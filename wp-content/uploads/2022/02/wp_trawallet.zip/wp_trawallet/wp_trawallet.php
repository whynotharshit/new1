<?php
/**
 * Plugin Name: WP TeraWallet
 * Plugin URI: http://larasoftbd.net/
 * Description: TeraWallet without woocommerce. 
 * Version: 1.0.0
 * Author: larasoft
 * Author URI: https://larasoftbd.net
 * Text Domain: teraWallet
 * Domain Path: /languages
 * Requires at least: 4.0.0
 * Tested up to: 5.0
 *
 * @package     teraWallet
 * @category 	Core
 * @author 		LaraSoft
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define('teraWalletDIR', plugin_dir_path( __FILE__ ));
define('teraWalletURL', plugin_dir_url( __FILE__ ));


// Define WOO_WALLET_PLUGIN_FILE.
if ( ! defined( 'WOO_WALLET_PLUGIN_FILE' ) ) {
    define( 'WOO_WALLET_PLUGIN_FILE', __FILE__);
}

require_once(teraWalletDIR . 'inc/class.php');
require_once(teraWalletDIR . 'inc/woo-wallet/woo-wallet.php');

new teraWalletClass;



// add_action('wp_head', 'testfunction');
function testfunction(){
    // echo 'paypal name: ' . WC_Gateway_Paypal::init_settings();
    
    $paypalSettings = get_option( 'woocommerce_paypal_settings' );
    echo '<pre>';
    print_r($paypalSettings);
    echo '</pre>';
}





