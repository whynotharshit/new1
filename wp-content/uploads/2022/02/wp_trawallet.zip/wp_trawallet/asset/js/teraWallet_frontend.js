jQuery(document).ready(function($){



     /*
    * Set user tid
    */
   jQuery(document).on('click', 'input#pay_now', function(e){
    e.preventDefault();
    var form = jQuery(this).closest('form');

    jQuery.ajax({
        url: myajax.ajaxurl,
        type: 'post',
        data: { 
            action: 'setusertid'
        },
        dataType: 'json',
        success: function(data) {
            if(data.tid) {	
                form.find('input[name="return"]').val(form.find('input[name="return"]').val() + '&tid=' + data.tid );
                form.submit();
            }
        }, 
        error: function(){
            console.log('error');
        }
    });
   });

    // "user strict";
    jQuery(document.body).on('click', 'button#changetrawalletsk', function(e){
        e.preventDefault();
        var thisbutton = $(this);
        $.ajax({
            type : 'POST',
            dataType : 'json',
            url : myajax.ajaxurl,
            data : {
                action: "changetrawalletsk", 
                test:'test'
            },
            success: function(data) {
                if(data.msg == 'success'){
                    jQuery( "<p class='successtrawallet msg-success'>Your SK Change to: "+data.sk+"</p>" ).insertBefore( thisbutton );
                }
            }, 
            error:function(error){
                console.log(error);
            }
         });   
    });



    /*
    * Continue payment 
    */
   jQuery(document).on('click', 'button#continue_topup', function(e){
    e.preventDefault();
    var type = jQuery('input[name="payment_type"]:checked').val();
    var amount = jQuery('input#woo_wallet_balance_to_add').val();
    var thissection = jQuery(this).closest('div.topupform');
    var error = '';
    
    if(amount == '') error += '<li>Amount field are required.</li>';
    if(typeof type == 'undefined') error += '<li>Payment type is required.</li>';
    amount = parseInt(amount);
    if(error !=''){
        jQuery('#topuperror').html('<ul>'+error+'</ul>');
    }
    if(type == 'payu' && error == ''){
        thissection.hide();
        $('div.payu').removeClass('d-none');
    } // End if

    if(type == 'paypal' && error == ''){
        $('form#paypal_form input[name="amount"]').val(amount.toFixed(2));
        $('form#paypal_form input[name="return"]').val($('form#paypal_form input[name="return"]').val() + '&amount='+amount.toFixed(2));
        thissection.hide();
        $('div.paypal').removeClass('d-none');
    }

    if(type == 'commerce' && amount !=''){
        $.ajax({
            url: myajax.ajaxurl,
            type: 'post',
            data: { 
                amount: amount,
                current_url: myajax.current_url,
                action: 'createCoinbaseChackoutId'
            },
            dataType: 'json',
            success: function(data) {
                // console.log(data);
                if(data.result == 'success') {	
                    jQuery('a.donate-with-crypto').attr('href', data.redirect);  
                    jQuery('a.donate-with-crypto').attr('data-price', amount); 
                    thissection.hide();
                    $('div.coinbase_ecommerce_payment').removeClass('d-none');
                }
            }
        }).done(onload);
    }

    if(type == 'stripe' && error == ''){
        thissection.hide();
        $('div.stripe').removeClass('d-none');
    }
   });


   /*
   * PayU Payment
   */
  jQuery(document).on('submit', 'form#payu_payment_form', function(e){
    e.preventDefault();
    var amount = jQuery('input#woo_wallet_balance_to_add').val();
    $.ajax({
        url: myajax.ajaxurl,
        type: 'post',
        data: { 
            amount: amount,
            current_url: myajax.current_url,
            action: 'payUFormSubmitProcessReturnURL'
        },
        dataType: 'json',
        success: function(data) {
            // console.log(data);
            if(data.pay_url) {	
            //    console.log(data.pay_url['redirect']); 
               location.href = data.pay_url['redirect']
            }
        }
    });
  });

   /*
   * CSV upload function 
   */
  function toggleCSVForm(){
    var checkval = jQuery('input[name="transver"]:checked').val();
    // console.log(checkval);
    if(checkval == 'transfer'){
        jQuery('div#transver').show();
        jQuery('div#csvTransfer, #CreateButton').hide();
    }
    else if(checkval == 'csv_upload'){
        jQuery('div#transver, #CreateButton').hide();
        jQuery('div#csvTransfer').show();
    }
    else{
        jQuery('div#transver, div#csvTransfer').hide();
        jQuery('div#CreateButton').show();
    }
  }
  toggleCSVForm();
  jQuery(document).on('change', 'input[name="transver"]', function(){
    toggleCSVForm();
  });

  // UPload csv via ajax
    $('input[name=csv_upload]').change(function() {
        

        var name = document.getElementById("csv_upload").files[0].name;
        var form_data = new FormData();
        var ext = name.split('.').pop().toLowerCase();
        if(jQuery.inArray(ext, ['csv']) == -1) 
        {
        alert("Invalid CSV File");
        }
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("csv_upload").files[0]);
        var f = document.getElementById("csv_upload").files[0];
        var fsize = f.size||f.fileSize;
        if(fsize > 2000000)
        {
        alert("Image File Size is very big");
        }
        else
        {
        form_data.append("upload_csv", document.getElementById('csv_upload').files[0]);
        form_data.append("action", 'csvUploadAjax');
        $.ajax({
        url:myajax.ajaxurl,
        method:"POST",
        data: form_data,
        dataType: 'json',
        contentType: false,
        cache: false,
        processData: false,
        beforeSend:function(){
        $('#uploadcsv').html("<label class='text-success'>CSV Uploading...</label>");
        },   
        success:function(data)
        {
            if(data.msg == 'success'){
                $('#uploadcsv').html("<label class='text-success'>CSV Upload Complete...</label>");	
            }
        }
        });
        }

    });




     /*
	 * Create Transfarable form
	 */
	jQuery(document).on('click', 'button#createform', function(e){
		e.preventDefault();
		var amount = jQuery('input[name="transfarable_amount"]').val(),
		error = '',
		form = '',
		action = jQuery('textarea[name="trawallet_transation"]').data('url'),
		transfer_to = jQuery('textarea[name="trawallet_transation"]').data('id');

		
        // if(amount == '') error +='<ul class="error"><li>Amount field is required.</li></ul>';
        // console.log( 'amount: ' + amount);
		
		if(error != ''){ 
            jQuery('div.errormsg').html(error);
            jQuery('input[name="transfarable_amount"]').addClass('error');
		}else{
            jQuery('div.errormsg').html('');
            jQuery('input[name="transfarable_amount"]').removeClass('error');
			form += '<form method="post" action="'+action+'/">'
			+'<input type="hidden" name="t_remot_amount" value="'+amount+'" />'
			+'<input type="hidden" name="transfer_to" value="'+transfer_to+'"/>'
			+'<input type="submit" value="Submit" class="t_submit" />'
			+'</form>';
			jQuery('textarea[name="trawallet_transation"]').val(form);
			jQuery('textarea[name="trawallet_transation"]').removeClass('d-none');

		}
	});
 

    jQuery(document).on('click', 'span.close-button', function(){
        jQuery('div#user_guide_wrap').animate({
            left:'-100%'
        });
    });

    jQuery(document).on('click', 'a#user_guide', function(){
        jQuery('div#user_guide_wrap').animate({
            left:'0%'
        });
    });



   
 
});  // End Document Ready




function launchBOLT()
{
	bolt.launch({
	key: jQuery('#key').val(),
	txnid: jQuery('#txnid').val(), 
	hash: jQuery('#hash').val(),
	amount: jQuery('input#woo_wallet_balance_to_add').val(),
	firstname: jQuery('#fname').val(),
	email: jQuery('#email').val(),
	phone: jQuery('#mobile').val(),
	productinfo: jQuery('#pinfo').val(),
	udf5: jQuery('#udf5').val(),
	surl : jQuery('#surl').val(),
	furl: jQuery('#surl').val(),
	mode: 'dropout'	
},
{ responseHandler: function(BOLT){
	// console.log( 'omar: ' + BOLT.response.txnStatus );		
	if(BOLT.response.txnStatus != 'CANCEL')
	{
		//Salt is passd here for demo purpose only. For practical use keep salt at server side only.
		var fr = '<form action=\"'+jQuery('#surl').val()+'\" method=\"post\">' +
		'<input type=\"hidden\" name=\"key\" value=\"'+BOLT.response.key+'\" />' +
		'<input type=\"hidden\" name=\"salt\" value=\"'+jQuery('#salt').val()+'\" />' +
		'<input type=\"hidden\" name=\"txnid\" value=\"'+BOLT.response.txnid+'\" />' +
		'<input type=\"hidden\" name=\"amount\" value=\"'+BOLT.response.amount+'\" />' +
		'<input type=\"hidden\" name=\"productinfo\" value=\"'+BOLT.response.productinfo+'\" />' +
		'<input type=\"hidden\" name=\"firstname\" value=\"'+BOLT.response.firstname+'\" />' +
		'<input type=\"hidden\" name=\"email\" value=\"'+BOLT.response.email+'\" />' +
		'<input type=\"hidden\" name=\"udf5\" value=\"'+BOLT.response.udf5+'\" />' +
		'<input type=\"hidden\" name=\"mihpayid\" value=\"'+BOLT.response.mihpayid+'\" />' +
		'<input type=\"hidden\" name=\"status\" value=\"'+BOLT.response.status+'\" />' +
		'<input type=\"hidden\" name=\"hash\" value=\"'+BOLT.response.hash+'\" />' +
		'</form>';
		var form = jQuery(fr);
		jQuery('body').append(form);								
        form.submit();
	}
},
	catchException: function(BOLT){
 		alert( 't: ' + BOLT.message );
	}
});
}