jQuery(document).ready( function($) {
	$('.wp-tab-bar a').click(function(event){
		event.preventDefault();
		
		// Limit effect to the container element.
		var context = $(this).closest('.wp-tab-bar').parent();
		$('.wp-tab-bar li', context).removeClass('wp-tab-active');
		$(this).closest('li').addClass('wp-tab-active');
		$('.wp-tab-panel', context).hide();
		$( $(this).attr('href'), context ).show();
	});

	// Make setting wp-tab-active optional.
	$('.wp-tab-bar').each(function(){
		if ( $('.wp-tab-active', this).length )
			$('.wp-tab-active', this).click();
		else
			$('a', this).first().click();
	});


	/*
	* Stripe toggle mode on backend
	*/

	function modeChange(){
		if(jQuery('input[name="_wallet_settings_general[stripe]"]').is(':checked')){
			jQuery('tr.stripe_mode').show();
			if(jQuery('input[name="_wallet_settings_general[stripe_mode]"]').is(':checked')){
				jQuery('tr.live_publish_key, tr.live_secret_key').hide();
				jQuery('tr.test_publish_key, tr.test_secret_key').show();
			}else{
				jQuery('tr.live_publish_key, tr.live_secret_key').show();
				jQuery('tr.test_publish_key, tr.test_secret_key').hide();
			}
		}else{
			jQuery('tr.test_publish_key, tr.test_secret_key, tr.live_publish_key, tr.live_secret_key, tr.stripe_mode').hide();
		}
		
	}
	modeChange();
	jQuery(document).on('change', 'input[name="_wallet_settings_general[stripe]"], input[name="_wallet_settings_general[stripe_mode]"]', function(){
		modeChange();	
	});


	function showhideCoinbase(){
		if(jQuery('input[name="_wallet_settings_general[coinbase_commerce]"]').is(':checked')){
			jQuery('tr.coinbase_webhook, tr.coinbase_hook_secrate_key').show();
		}else{
			jQuery('tr.coinbase_webhook, tr.coinbase_hook_secrate_key').hide();
		}
	}

	jQuery(document).on('change', 'input[name="_wallet_settings_general[coinbase_commerce]"]', function(){
		showhideCoinbase();	
	});


	/*
	* Change PayU mode
	*/
	function modeChangePayU(){
		if(jQuery('input[name="_wallet_settings_general[payu]"]').is(':checked')){
			jQuery('tr.payu_mode').show();
			if(jQuery('input[name="_wallet_settings_general[payu_mode]"]').is(':checked')){
				jQuery('tr.payu_merchant_key, tr.payu_merchant_salt').hide();
				jQuery('tr.payu_merchant_key_test, tr.payu_merchant_salt_test').show();
			}else{
				jQuery('tr.payu_merchant_key, tr.payu_merchant_salt').show();
				jQuery('tr.payu_merchant_key_test, tr.payu_merchant_salt_test').hide();
			}
		}else{
			jQuery('tr.payu_mode, tr.payu_merchant_key, tr.payu_merchant_salt, tr.payu_merchant_key_test, tr.payu_merchant_salt_test').hide();
		}
		
	}
	modeChangePayU();
	jQuery(document).on('change', 'input[name="_wallet_settings_general[payu]"], input[name="_wallet_settings_general[payu_mode]"]', function(){
		modeChangePayU();	
	});


	/*
	* CSV upload
	*/

	
	$('input[name=upload_csv]').change(function() {
	

		var name = document.getElementById("upload_csv").files[0].name;
		var form_data = new FormData();
		var ext = name.split('.').pop().toLowerCase();
		if(jQuery.inArray(ext, ['csv']) == -1) 
		{
		 alert("Invalid CSV File");
		}
		var oFReader = new FileReader();
		oFReader.readAsDataURL(document.getElementById("upload_csv").files[0]);
		var f = document.getElementById("upload_csv").files[0];
		var fsize = f.size||f.fileSize;
		if(fsize > 2000000)
		{
		 alert("Image File Size is very big");
		}
		else
		{
		 form_data.append("upload_csv", document.getElementById('upload_csv').files[0]);
		 form_data.append("action", 'csvUploadAjax');
		 $.ajax({
		  url:ajaxurl,
		  method:"POST",
		  data: form_data,
		  dataType: 'json',
		  contentType: false,
		  cache: false,
		  processData: false,
		  beforeSend:function(){
		   $('#uploadcsv').html("<label class='text-success'>CSV Uploading...</label>");
		  },   
		  success:function(data)
		  {
			if(data.msg == 'success'){
				$('#uploadcsv').html("<label class='text-success'>CSV Upload Complete...</label>");	
			}
		  }
		 });
		}

	 });
	 

	 /*
	 * Create Transfarable form
	 */
	jQuery(document).on('click', 'button#createform', function(e){
		e.preventDefault();
		var amount = jQuery('input[name="_wallet_settings_button[transfarable_amount]"]').val(),
		error = '',
		form = '',
		action = jQuery('textarea[name="trawallet_transation"]').data('url'),
		transfer_to = jQuery('select[name="_wallet_settings_button[transfer_to]"]').val();

		
		// if(amount == '') error +='<ul class="error"><li>Amount field is required.</li></ul>';
		
		if(error != ''){ 
			jQuery('div.errormsg').html(error);
		}else{
			jQuery('div.errormsg').html('');
			form += '<form method="post" action="'+action+'/">'
			+'<input type="hidden" name="t_remot_amount" value="'+amount+'" />'
			+'<input type="hidden" name="transfer_to" value="'+transfer_to+'"/>'
			+'<input type="submit" value="Submit" class="t_submit" />'
			+'</form>';
			jQuery('textarea[name="trawallet_transation"]').val(form);
			

		}



	});

});