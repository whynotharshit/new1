
<div>
  <a id="pay_withcripto" class="donate-with-crypto btn btn-primary mt-1"  rel="noopener noreferrer" href="#">
    <span><?php _e('Topup with Crypto', 'wp_trawallet'); ?></span>
  </a>
</div>