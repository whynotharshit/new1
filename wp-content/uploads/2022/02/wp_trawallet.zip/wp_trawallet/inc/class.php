<?php
/*
* teraWallet Class 
*/

require_once(teraWalletDIR . 'inc/inc_Stripe_handler.php');
// require_once(teraWalletDIR . 'inc/inc_coinbaseecommerce.php');



use trawallet\stripe\Stripe_handler as Stripe_handler;
// use trawallet\coinbase\coinbasePayment as coinbasePayment;


if (!class_exists('teraWalletClass')) {
    class teraWalletClass{
        public $plugin_url;
        public $plugin_dir;
        public $wpdb;
        public $option_tbl; 
        
        /** @var bool Whether or not logging is enabled */
	    public static $log_enabled = false;
        
        /**Plugin init action**/ 
        public function __construct() {
            global $wpdb;
            $this->plugin_url 				= teraWalletURL;
            $this->plugin_dir 				= teraWalletDIR;
            $this->wpdb 					= $wpdb;	
            $this->option_tbl               = $this->wpdb->prefix . 'options';
         
            $this->init();
        }

        private function init(){
            // Change SK using ajax request 
            add_action("wp_ajax_nopriv_changetrawalletsk", array($this, "changetrawalletsk"));
            add_action("wp_ajax_changetrawalletsk", array($this, "changetrawalletsk"));

            // Change SK using ajax request 
            add_action("wp_ajax_nopriv_stripePaymentHandler", array($this, "stripePaymentHandler"));
            add_action("wp_ajax_stripePaymentHandler", array($this, "stripePaymentHandler"));

            // Coinbase Checkout id
            add_action("wp_ajax_nopriv_createCoinbaseChackoutId", array($this, "createCoinbaseChackoutId"));
            add_action("wp_ajax_createCoinbaseChackoutId", array($this, "createCoinbaseChackoutId"));

            // Upload CSV via ajax
            add_action("wp_ajax_nopriv_csvUploadAjax", array($this, "csvUploadAjax"));
            add_action("wp_ajax_csvUploadAjax", array($this, "csvUploadAjax"));

            // Payu REturn payment url via ajax
            add_action("wp_ajax_nopriv_payUFormSubmitProcessReturnURL", array($this, "payUFormSubmitProcessReturnURL"));
            add_action("wp_ajax_payUFormSubmitProcessReturnURL", array($this, "payUFormSubmitProcessReturnURL"));


            // Create iser tod
            add_action("wp_ajax_nopriv_setusertid", array($this, "setusertid"));
            add_action("wp_ajax_setusertid", array($this, "setusertid"));
            

            //Backend Script
            add_action( 'admin_enqueue_scripts', array($this, 'larasoft_teraWallet_backend_script') );
            //Frontend Script
            add_action( 'wp_enqueue_scripts', array($this, 'larasoftbd_teraWallet_frontend_script') );


            //TeraWallet Generate Number
            add_action('init', array($this, 'teraWallet_generate_number'));

            //Change Admin User list struction
            add_filter('manage_teraWallet_posts_columns', array($this, 'replaceteraWalletListColumn'));
            add_action('manage_teraWallet_posts_custom_column', array($this, 'getteraWalletshortcodeList'), 10, 2);
            add_filter( 'manage_teraWallet_posts_columns', array($this, 'reorderteraWallet_columns') );

            // start add custom field 
            add_action( 'show_user_profile', array($this, 'extra_user_profile_fields' ));
            add_action( 'edit_user_profile', array($this, 'extra_user_profile_fields' ));

            // add_action('admin_init', array($this, 'my_general_section') );  

            // Shortcode for frontend use
            add_shortcode( 'terawallet-change-sk', array($this, 'larasoftbd_shortcode_shortcode') );
            add_shortcode( 'trawallet', array($this, 'larasoftbd_shortcodeforuserinfo') );

            // Coinbase webhook
            // if(isset($_REQUEST['webhook'])) add_action( 'init', array($this, 'webhookCotroller') );
            
            // Transfer from remote form 
            add_action( 'wp_footer', array($this, 'remoteTransation') );
            // Add additional attributes in js 
            // add_filter('script_loader_src', array($this, 'add_id_to_script'), 10, 2);
            // add_action( 'wp_head', array($this, 'testfunctoon'));
            
        }
        

        public function testfunctoon(){
            $coinbase_payment_url = $this->coinbase_process_payment(20);
            echo 'coinbase payment url: <br/>';
            echo '<pre>';
            print_r($coinbase_payment_url);
            echo '</pre>';
            // $returnurl = 'http://127.0.0.1/wordpress/woo-wallet/?status=success&amount=50.00&tid=11581762477';
            // $amount = 50;
            // $payu_url = process_payment($returnurl, $amount);
            // echo '<pre>';
            // print_r($payu_url);
            // echo '</pre>';
        }


    /**
	 * Logging method.
	 *
	 * @param string $message Log message.
	 * @param string $level   Optional. Default 'info'.
	 *     emergency|alert|critical|error|warning|notice|info|debug
	 */
	public static function log( $message, $level = 'info' ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				self::$log = wc_get_logger();
			}
			self::$log->log( $level, $message, array( 'source' => 'coinbase' ) );
		}
	}

    public function coinbase_init_api() {
            $coinbase_settings = get_option( 'woocommerce_coinbase_settings' );
            include_once WP_PLUGIN_DIR . '/coinbase-commerce/includes/class-coinbase-api-handler.php';
            Coinbase_API_Handler::$log     = get_class( $this ) . '::log';
            Coinbase_API_Handler::$api_key = $coinbase_settings['api_key'];
    }


    /**
	 * Process the payment and return the result.
	 * @param  int $order_id
	 * @return array
	 */
	public function coinbase_process_payment( $amount, $return_url, $cancel_url, $tid ) {
		// Create description for charge based on order's products. Ex: 1 x Product1, 2 x Product2
		try {
			$description = mb_substr( __('Coinbase Trawallet Topup', 'trawallet'), 0, 200 );
		} catch ( Exception $e ) {
			$description = null;
		}

		$this->coinbase_init_api();

		// Create a new charge.
		$metadata = array(
			'order_id'  => $tid,
			'order_key' => 'key_' . $tid,
            		'source' => 'WP Trawallet'
		);
		$result   = Coinbase_API_Handler::create_charge(
			$amount, get_woocommerce_currency(), $metadata,
			$return_url, null, $description,
			$cancel_url
		);

		if ( ! $result[0] ) {
			return array( 'result' => 'fail' );
		}

		$charge = $result[1]['data'];

		return array(
			'result'   => 'success',
			'redirect' => $charge['hosted_url'],
		);
	}


        /*
        * Return PayU payent url
        */
        public function payUFormSubmitProcessReturnURL(){
            $tid = $this->tid();
            $amount = $_POST['amount'] * 100;
            $return_url = $_POST['current_url'] . '?status=success&amount='.$_POST['amount'].'&tid='.$tid.'';
            // http://127.0.0.1/wordpress/woo-wallet/?status=success&amount=50.00&tid=11581762477
            $payu_url = process_payment($return_url, $amount);

            echo json_encode( array(
                'tid' => $tid,
                'pay_url' => $payu_url,
                'return_url' => $return_url
            ) );
            wp_die();
        }



        /*
        * User Tid
        */
        public function tid(){
            $transation_id = get_current_user_id() . time();
            update_user_meta( get_current_user_id(), 'tid', $transation_id );
            $updatemeta = get_user_meta( get_current_user_id(), 'tid', true );
            return $updatemeta;
        }
        /*
        * Set User TID
        */
        public function setusertid(){
            $tid = $this->tid();
            echo json_encode( array(
                'tid' => $tid
            ) );
            wp_die();
        }

        /*
        * Trawallet user info shortcode
        */
        public function larasoftbd_shortcodeforuserinfo($args){
            if(is_user_logged_in()):
                $teraWallet_key = get_user_meta( get_current_user_id(), 'teraWallet_key', true );
                
                $output = '';
                if(isset($args['show'])){
                    switch($args['show']){
                        case 'ID':
                            $output = $teraWallet_key[0];
                        break;
                        case 'SK':
                            $output = $teraWallet_key[2];
                        break;
                        case 'member-no':
                            $output = $teraWallet_key[1];
                        break;
                    }
                }
                return $output;
            endif;
        }



        /*
        * Get user id by meta SK
        */
        public function get_user_id_by_trawallet_key($sk){
            $user = get_users(
                array(
                 'meta_key' => 'teraWallet_key',
                 'meta_value' => $sk,
                 'meta_compare' => 'LIKE',
                 'number' => 1,
                 'count_total' => false
            ) );
            $id = ($user) ? $user[0]->ID : '';
            return $id;
        }


        /**
         * Do transfer wallet amount.
         * @return array
         */
        public function do_wallet_transfer_api($userid, $whom, $amount) {
            $response = array('is_valid' => true, 'message' => '');

                $whom = apply_filters('woo_wallet_transfer_user_id', $whom);
                // echo 'whom: ' . $whom . '<br/>';
                $whom = get_userdata($whom);
                if($whom):
                    $current_user_obj = get_userdata($userid);
                    $credit_note = isset($_POST['woo_wallet_transfer_note']) && !empty($_POST['woo_wallet_transfer_note']) ? $_POST['woo_wallet_transfer_note'] : sprintf(__('Wallet funds received from %s', 'woo-wallet'), $current_user_obj->user_email);
                    $debit_note = sprintf(__('Wallet funds transfer to %s', 'woo-wallet'), $whom->user_email);
                    $credit_note = apply_filters('woo_wallet_transfer_credit_transaction_note', $credit_note, $whom, $amount);
                    $debit_note = apply_filters('woo_wallet_transfer_debit_transaction_note', $debit_note, $whom, $amount);
                endif;
                $transfer_charge_type = woo_wallet()->settings_api->get_option('transfer_charge_type', '_wallet_settings_general', 'percent');
                $transfer_charge_amount = woo_wallet()->settings_api->get_option('transfer_charge_amount', '_wallet_settings_general', 0);
                $transfer_charge = 0;
                if ('percent' === $transfer_charge_type) {
                    $transfer_charge = ( $amount * $transfer_charge_amount ) / 100;
                } else {
                    $transfer_charge = $transfer_charge_amount;
                }
                $transfer_charge = apply_filters('woo_wallet_transfer_charge_amount', $transfer_charge, $whom);
                $credit_amount = apply_filters('woo_wallet_transfer_credit_amount', $amount, $whom);
                $debit_amount = apply_filters('woo_wallet_transfer_debit_amount', $amount + $transfer_charge, $whom);
                if ( woo_wallet()->settings_api->get_option( 'min_transfer_amount', '_wallet_settings_general', 0 ) ) {
                    if ( woo_wallet()->settings_api->get_option( 'min_transfer_amount', '_wallet_settings_general', 0 ) > $amount) {
                        return array(
                            'is_valid' => false,
                            'message' => sprintf( __('Minimum transfer amount is %s', 'woo-wallet'), wc_price( woo_wallet()->settings_api->get_option( 'min_transfer_amount', '_wallet_settings_general', 0 ), woo_wallet_wc_price_args() ) )
                        );
                    }
                }
                if (!$whom) {
                    return array(
                        'is_valid' => false,
                        'message' => __('Invalid user', 'woo-wallet')
                    );
                }
                if (floatval($debit_amount) > woo_wallet()->wallet->get_wallet_balance($userid, 'edit')) {
                    return array(
                        'is_valid' => false,
                        'message' => __('Entered amount is greater than current wallet amount.', 'woo-wallet')
                    );
                }

                if ($credit_transaction_id = woo_wallet()->wallet->credit($whom->ID, $credit_amount, $credit_note)) {
                    do_action('woo_wallet_transfer_amount_credited', $credit_transaction_id, $whom->ID, $userid);
                    $debit_transaction_id = woo_wallet()->wallet->debit($userid, $debit_amount, $debit_note);
                    do_action('woo_wallet_transfer_amount_debited', $debit_transaction_id, $userid, $whom->ID);
                    update_wallet_transaction_meta($debit_transaction_id, '_wallet_transfer_charge', $transfer_charge, $userid);
                    $response = array(
                        'is_valid' => true,
                        'message' => __('Amount transferred successfully!', 'woo-wallet')
                    );
                }
            
            return $response;
        }
        /*
        * REmote Transation
        */
        public function remoteTransation(){
            if(isset($_POST['t_submit_final'])){
                
            $keys = array($_POST['id'], $_POST['member_no'], $_POST['sk']);
            $keys = serialize($keys);

            $userid = $this->get_user_id_by_trawallet_key($keys);            

            $whom = $this->get_user_id_by_trawallet_key($_POST['transfer_to']);


            $transfer = $this->do_wallet_transfer_api($userid, $whom, $_POST['amount']);

                if($transfer['is_valid']){
                    $_POST = array();
                    wp_safe_redirect( get_home_url( ) ); exit;
                }
            }

            $transfer_to = (isset($_POST['transfer_to']))? $_POST['transfer_to'] : '';
            $amount = (isset($_POST['t_remot_amount']))? $_POST['t_remot_amount'] : '';

            if(!empty($transfer_to)){ 
                ob_start();
                ?>
                    <div id="transferForm">
                        <form method="post" action="" id="transferFormForm">
                        <div class="form-group">
                            <label for="sk"><?php _e('SK', 'trawallet'); ?></label>
                            <input type="text" name="sk" class="form-control" id="sk">
                        </div>
                        <div class="form-group">
                            <label for="id"><?php _e('ID', 'trawallet'); ?></label>
                            <input type="text" name="id" class="form-control" id="id">
                        </div>
                        <div class="form-group">
                            <label for="lamminaa_id"><?php _e('Enter Lamminaa ID', 'trawallet'); ?></label>
                            <input type="text" name="transfer_to" value="<?php echo $_POST['transfer_to']; ?>" class="form-control" id="lamminaa_id">
                        </div>
                        <div class="form-group">
                            <label for="lamminaa_amount"><?php _e('Enter Amount', 'trawallet'); ?></label>
                            <input type="number" step="0.01" name="amount" value="<?php echo $amount ?>" class="form-control" id="lamminaa_amount">
                        </div>
                        <div class="form-group">
                            <label for="member_no"><?php _e('Member No', 'trawallet'); ?></label>
                            <input type="text" name="member_no" class="form-control" id="member_no">
                        </div>
                        <div class="form-group">
                            <label for="woo_wallet_transfer_note"><?php _e('Transfer Note', 'trawallet'); ?></label>
                            <textarea name="woo_wallet_transfer_note" id="woo_wallet_transfer_note" class="w-100" rows="2"></textarea>
                        </div>
                        <input class="btn btn-primary" name="t_submit_final" type="submit" value="<?php _e('Process Payment', 'trawallet'); ?>">
                        </form>
                    </div>
                <?php
                $html = ob_get_clean();
                echo $html;
            }
        }


        /*
        * Upload csv via ajax
        */
        public function csvUploadAjax(){

            $fileName = $_FILES["upload_csv"]["tmp_name"];
    
            $success = array();
            if ($_FILES["upload_csv"]["size"] > 0) {
                
                $file = fopen($fileName, "r");
                $loop = 0;
                $transaction_id = '';
                while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                    $user_id = $this->get_user_id_by_trawallet_key($column[0]);
                    if($loop != 0) array_push($success, $column);
                    if($column[1] !=''){
                        $transaction_id = woo_wallet()->wallet->credit( $user_id, $column[1], $column[2]);
                    }
                    $loop +=1;
                }
            }

            $msg = ($transaction_id !='') ? 'success' : 'fail';

            echo json_encode(
                array(
                    'msg' => $msg
                )
            );
            wp_die();
        }


        /*
        * Webhook
        */
        public function webhookCotroller(){
            $ecommerce = new coinbasePayment;
            $price = $ecommerce->webhook();
            if($price){
                $transaction_id = woo_wallet()->wallet->credit( get_current_user_id(), $price, 'wallet credit with Coinbase');
            }
        }
       
        /*
        * Coinbase Checkout ID
        */
        public function createCoinbaseChackoutId(){
            $tid = $this->tid();
            $amount = $_REQUEST['amount'];
            $return_url = $_REQUEST['current_url'];
            $return_url = $return_url . '?status=success&amount='.$amount.'&tid='.$tid.'';
            $cancel_url = $_REQUEST['current_url'] . '?status=cancel';

            $coinbase_payment_url = $this->coinbase_process_payment($amount, $return_url, $cancel_url, $tid);
            echo json_encode($coinbase_payment_url);
            wp_die();
        }
        /*
        * Stripe payment with ajax 
        * Function call from trawallet_stripe.js
        */
        public function stripePaymentHandler(){
            $stripehandler = new Stripe_handler;
            $pament_charge = '';
            $amount = $_REQUEST['amount'];
            $_REQUEST['amount'] = (int)$_REQUEST['amount'] * 100;
            if(isset($_POST['stripeToken'])){
                $pament_charge = $stripehandler->charge_customer($_REQUEST);
            }

            if($pament_charge !=''){
                $transaction_id = woo_wallet()->wallet->credit( get_current_user_id(), $amount, 'wallet credit using Stripe');
            }

            echo json_encode(
                array(
                    'return' => $pament_charge,
                    'transaction_id' => $transaction_id
                )
            );
            wp_die();
        }
        /*
        * Add additional attributs to enqueue js
        */
        public function add_id_to_script($src, $handle){
            echo 'handle: ' . $handle . '<br/>';
            if ($handle == 'bolt'){
                echo 'src: ' . $src;
                $src . "' id='dropboxjs' data-app-key='MY_APP_KEY";
            } 
            return $src;
        }

        
        /*
        * Change SK by user click 
        */
        function changetrawalletsk(){
            $teraWallet_key = get_user_meta( get_current_user_id(), 'teraWallet_key', true );
            $number  = $this->generateGUID($teraWallet_key, true);
            $msg = ($number) ? 'success' : 'fail';
            echo json_encode(
                array(
                    'msg' => $msg,
                    'sk' => $number
                )
            );
            wp_die();
        }
        /*
        * Appointment backend Script
        */
        function larasoft_teraWallet_backend_script(){
            
            wp_enqueue_style( 'larasoftteraWalletCSS', $this->plugin_url . 'asset/css/teraWallet_backend.css', array(), true, 'all' );

            wp_enqueue_script( 'larasoftteraWalletJS', $this->plugin_url . 'asset/js/teraWallet_backend.js', array(), true );

        }

        /*
        * Appointment frontend Script
        */
        function larasoftbd_teraWallet_frontend_script(){
            $stripehandler = new Stripe_handler;
            global $post;

            
            // $_POST['user_sk'] = '112';;;;
            

            wp_enqueue_style( 'larasoftbd_teraWalletCSS', $this->plugin_url . 'asset/css/teraWallet_frontend.css', array(), true, 'all' );


            // wp_enqueue_script( 'bolt', 'https://sboxcheckout-static.citruspay.com/bolt/run/bolt.min.js', array('jquery'), time(), false );
            
            wp_enqueue_script( 'larasoftbd_teraWalletJS', $this->plugin_url . 'asset/js/teraWallet_frontend.js', array('jquery'), time(), true );
            wp_localize_script( 'larasoftbd_teraWalletJS', 'myajax', array( 
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'stripe_publish_key' => $stripehandler->publish_key,
                'current_url' => get_the_permalink( $post->ID )
            )
            ); 
            if(isset($_REQUEST['wl']) && $_REQUEST['wl'] == 'top_up' && class_exists('WC_Gateway_Stripe')) wp_enqueue_script( 'larasoftbd_stripejs', $this->plugin_url . 'asset/js/trawallet_stripe.js', array('jquery'), time(), true );
        }



        /*
        * Generate Guid Number 
        */
        function generateGUID($teraWallet_key, $updateSK = false){
            if( $teraWallet_key == '' && $updateSK == false ){
                $memberArray = array();
                for($s=0; $s < 3; $s++ ){

                    $guid = (string)time();
                    $member = "";
                    $numbers = array( 16, 8, 3);

                    for ($i = 0; $i < $numbers[$s]; $i++) $member .= $guid[mt_rand(0, strlen($guid)-1)];
                    array_push($memberArray, $member);

                }
                update_user_meta( get_current_user_id(), 'teraWallet_key', $memberArray );
            }elseif($updateSK == true){
                $guid = (string)time();
                $member = "";
                $numbers = 3;
                for ($i = 0; $i < $numbers; $i++) $member .= $guid[mt_rand(0, strlen($guid)-1)];
                $teraWallet_key[2] = $member;
                $update = update_user_meta( get_current_user_id(), 'teraWallet_key', $teraWallet_key );
                return $member;
            }
        }

        // TeraWallet Generate Number 
        function teraWallet_generate_number() {
            if(class_exists('WC_Gateway_PayU')){
                require_once(teraWalletDIR . 'inc/payu_additionalfunction.php');
            }
            if (isset($_POST['key'])) {
                $key				=   $_POST['key'];
                $salt				=   $_POST['salt'];
                $txnid 				= 	$_POST['txnid'];
                $amount      		= 	$_POST['amount'];
                $productInfo  		= 	$_POST['productinfo'];
                $firstname    		= 	$_POST['firstname'];
                $email        		=	$_POST['email'];
                $udf5				=   $_POST['udf5'];
                $mihpayid			=	$_POST['mihpayid'];
                $status				= 	$_POST['status'];
                $resphash			= 	$_POST['hash'];
                //Calculate response hash to verify	
                $keyString 	  		=  	$key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|||||'.$udf5.'|||||';
                $keyArray 	  		= 	explode("|",$keyString);
                $reverseKeyArray 	= 	array_reverse($keyArray);
                $reverseKeyString	=	implode("|",$reverseKeyArray);
                $CalcHashString 	= 	strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString));
                
                
                if ($status == 'success'  && $resphash == $CalcHashString) {
                    //Do success order processing here...
                    $transaction_id = woo_wallet()->wallet->credit( get_current_user_id(), $amount, 'wallet credit with PayU');
                }
            }

            
            /*
            * UPdate value from paypal
            */

            if(isset($_REQUEST['tid']) && $_REQUEST['tid'] == get_user_meta( get_current_user_id(), 'tid', true ) ){
                $transaction_id = woo_wallet()->wallet->credit( get_current_user_id(), $_REQUEST['amount'], 'wallet credit');
                if($transaction_id) update_user_meta( get_current_user_id(), 'tid', '');
            }

            // $payment = new coinbasePayment;
            // $paymentD = $payment->create_charge();
            // echo '<pre>';
            // print_r($paymentD->hosted_url);
            // echo '</pre>';

            $user_id = get_current_user_id();
            $teraWallet_key = get_user_meta( $user_id, 'teraWallet_key', true );
            $this->generateGUID($teraWallet_key, false);
        }



        

        // start custom field function
        function extra_user_profile_fields() {
            global $user_id; 
            $teraWallet_key = get_user_meta( $user_id, 'teraWallet_key', true );
            ob_start();
            ?>
            <h3><?php _e("Trawallet information", "blank"); ?></h3>
            <table class="form-table om">
            <tr>
                <th><label for="tra_id"><?php _e("ID"); ?></label></th>
                <td>
                    <input readonly type="text" name="tra_id" id="tra_id" value="<?php echo ($teraWallet_key) ? esc_attr(  $teraWallet_key[0] ) : ''; ?>" class="regular-text" /><br />
                    <span class="description"><?php _e("Trawallet author ID."); ?></span>
                </td>
            </tr>
            <tr>    
                <th><label for="member_no"><?php _e("Member No"); ?></label></th>
                <td>
                    <input readonly type="text" name="member_no" id="member_no" value="<?php echo ($teraWallet_key) ? esc_attr( $teraWallet_key[1] ) : ''; ?>" class="regular-text" /><br />
                    <span class="description"><?php _e("Trawallet Member No."); ?></span>
                </td>
            </tr>
            <tr>
            <th><label for="trawallet_sk"><?php _e("SK"); ?></label></th>
                <td>
                    <input readonly type="text" name="trawallet_sk" id="trawallet_sk" value="<?php echo ($teraWallet_key) ? esc_attr( $teraWallet_key[2] ) : ''; ?>" class="regular-text" /><br />
                    <span class="description"><?php _e("Trawallet SK Number."); ?></span>
                </td>
            </tr>
            </table>
        <?php 
          $output =  ob_get_clean();
          echo $output;
        }
        

        function larasoftbd_shortcode_shortcode(){
            $user_id = get_current_user_id();
            $teraWallet_key = get_user_meta( $user_id, 'teraWallet_key', true );
            ob_start();
        ?>
        <button data-url="<?php echo get_home_url(); ?>" id="changetrawalletsk" class="changesk btn btn-primary"><?php _e('Change SK', 'trawallet'); ?></button>
        <?php
        $output = ob_get_clean();
        return $output;
        }

    } // End Class
} // End Class check if exist / not
?>
