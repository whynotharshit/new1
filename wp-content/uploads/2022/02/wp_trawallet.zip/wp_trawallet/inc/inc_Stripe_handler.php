<?php
/**
 * Created by PhpStorm.
 * User: Themexplorer
 * Date: 1/12/2019
 * Time: 12:00 AM
 */

namespace trawallet\stripe;

require_once(teraWalletDIR . 'inc/payment-getway/vendor/autoload.php');

use Stripe\Stripe;
use Stripe\Account;

class Stripe_handler
{

    public $publish_key;
    private $secret_key;
    public function __construct()
    {        
        // woocommerce_stripe_settings
        $stripe_settings = get_option( 'woocommerce_stripe_settings' );
        // $testmode           = woo_wallet()->settings_api->get_option('stripe_mode', '_wallet_settings_general');
        // $test_publish_key   = woo_wallet()->settings_api->get_option('test_publish_key', '_wallet_settings_general');
        // $test_secret_key    = woo_wallet()->settings_api->get_option('test_secret_key', '_wallet_settings_general');
        // $live_publish_key   = woo_wallet()->settings_api->get_option('live_publish_key', '_wallet_settings_general');
        // $live_secret_key    = woo_wallet()->settings_api->get_option('live_secret_key', '_wallet_settings_general');


        $testmode           = (class_exists('WC_Gateway_Stripe')) ? $stripe_settings['testmode'] : '';
        $test_publish_key   = (class_exists('WC_Gateway_Stripe')) ? $stripe_settings['test_publishable_key']: '';
        $test_secret_key    = (class_exists('WC_Gateway_Stripe')) ? $stripe_settings['test_secret_key'] : '';
        $live_publish_key   = (class_exists('WC_Gateway_Stripe')) ? $stripe_settings['publishable_key'] : '';
        $live_secret_key    = (class_exists('WC_Gateway_Stripe')) ? $stripe_settings['secret_key'] : '';

        $this->publish_key  = $test_publish_key;
        $this->secret_key   = $test_secret_key;
        $stripe_mode = ($testmode != 'yes')?'live':'trial';
        if($stripe_mode == 'live'){
            $this->publish_key = $live_publish_key;
            $this->secret_key = $live_secret_key;
        }
        Stripe::setApiKey($this->secret_key);

    }

    public function get_publish_key(){
        return $this->publish_key;
    }

    function charge_customer($data){
            if(array_key_exists('stripeToken',$data)){
                $token = $data['stripeToken'];
                $charge = \Stripe\Charge::create([
                    'amount' => $data['amount'],
                    'currency' => 'usd',
                    'description' => 'Trawallet charge',
                    'source' => $token
                ]);
                // pri_dump($charge);
                return $charge->status;
            }
    }

    public function createcardtoken(){
        $token = \Stripe\Token::create([
            'card' => [
              'number' => '4242424242424242',
              'exp_month' => 1,
              'exp_year' => 2021,
              'cvc' => '314',
            ],
        ]);

        return $token->id;
    }
}
