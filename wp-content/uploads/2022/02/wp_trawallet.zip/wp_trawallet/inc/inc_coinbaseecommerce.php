<?php
namespace trawallet\coinbase;

require_once(teraWalletDIR . 'inc/payment-getway/vendor/autoload.php');
use CoinbaseCommerce\ApiClient;
use CoinbaseCommerce\Resources\Checkout;
use CoinbaseCommerce\Resources\Charge;
use CoinbaseCommerce\Webhook;

class coinbasePayment
{
    
    public $api_client;
    public $amount;

    public function __construct()
    {
        $this->api_client = ApiClient::init('16d31abc-5ed6-4c05-abc9-19701417d5a9');
    }

   

    public function create_checkout(){
        $checkoutData = [
            'name' => 'The Sovereign Individual',
            'description' => 'Mastering the Transition to the Information Age',
            'pricing_type' => 'fixed_price',
            'local_price' => [
                'amount' => '200.00',
                'currency' => 'USD'
            ],
            'requested_info' => ['name', 'email']
        ];
        $newCheckoutObj = Checkout::create($checkoutData);
        return $newCheckoutObj;
    }

    public function create_charge(){
        $amount = number_format((float)$this->amount, 2, '.', '');
        $chargeData = [
            'name' => 'The Sovereign Individual',
            'description' => 'Mastering the Transition to the Information Age',
            'local_price' => [
                'amount' => $amount,
                'currency' => 'USD'
            ],
            'pricing_type' => 'fixed_price'
        ];
        $charge  = Charge::create($chargeData);
        return $charge;
    }


    public function webhook(){

        /**
         * To run this example please read README.md file
         * Past your Webhook Secret Key from Settings/Webhook section
         * Make sure you don't store your Secret Key in your source code!
         */
        $secret = woo_wallet()->settings_api->get_option('coinbase_hook_secrate_key', '_wallet_settings_general'); // Hook Secreet Key
        $headerName = 'X-Cc-Webhook-Signature';
        $headers = getallheaders();
        $signraturHeader = isset($headers[$headerName]) ? $headers[$headerName] : null;
        $payload = trim(file_get_contents('php://input'));
        $success = false;
        try {
            $event = Webhook::buildEvent($payload, $signraturHeader, $secret);
            http_response_code(200);
            //echo sprintf('Successully verified event with id %s and type %s.', $event->id, $event->type);
            if($event->type == 'charge:confirmed'){
                $success = $event->data->metadata->price;
            }
        } catch (\Exception $exception) {
            http_response_code(400);
            echo 'Error occured. ' . $exception->getMessage();
            $success = false;
        }

        return $success;


    }


}