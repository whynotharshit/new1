<?php
/*
* 
*/



function getLanguage()
{
    return substr(get_locale(), 0, 2);
}

/** @return bool */
function isWpmlActiveAndConfigure() {
    global $woocommerce_wpml;

    return $woocommerce_wpml
        && property_exists($woocommerce_wpml, 'multi_currency')
        && $woocommerce_wpml->multi_currency
        && count($woocommerce_wpml->multi_currency->get_currency_codes()) > 1;
}


/**
* @return string
*/
function getIP()
    {
        return ($_SERVER['REMOTE_ADDR'] == '::1' || $_SERVER['REMOTE_ADDR'] == '::' ||
            !preg_match('/^((?:25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9]).){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])$/m',
                $_SERVER['REMOTE_ADDR'])) ? '127.0.0.1' : $_SERVER['REMOTE_ADDR'];
    }
function process_payment($return_url, $amount)
{
    $current_user = wp_get_current_user();
    $payusettings = get_option( 'woocommerce_payu_settings' );
    
    $isSandbox = 'yes' === $payusettings['sandbox'];
    $optionPrefix = $isSandbox ? 'sandbox_' : '';

    if (isWpmlActiveAndConfigure())
    {
        $optionSuffix = '_' . (null !== $currency ? $currency : get_woocommerce_currency());
    } else {
        $optionSuffix = '';
    }
    
    OpenPayU_Configuration::setEnvironment($isSandbox ? 'sandbox' : 'secure');

    OpenPayU_Configuration::setMerchantPosId($payusettings[$optionPrefix . 'pos_id' . $optionSuffix]);
    OpenPayU_Configuration::setSignatureKey($payusettings[$optionPrefix . 'md5' . $optionSuffix]);
    OpenPayU_Configuration::setOauthClientId($payusettings[$optionPrefix . 'client_id' . $optionSuffix]);
    OpenPayU_Configuration::setOauthClientSecret($payusettings[$optionPrefix . 'client_secret' . $optionSuffix]);

    OpenPayU_Configuration::setOauthTokenCache(new OauthCacheWP());
    OpenPayU_Configuration::setSender('Wordpress ver ' . get_bloginfo('version') . ' / WooCommerce ver ' . WC()->version . ' / Plugin ver 1.2.9 ');
    
    // $order = wc_get_order($order_id);
    // $billingData = $order->get_address();

    // $order->get_checkout_order_received_url()
    $orderData = array(
        'continueUrl' => $return_url,
        'notifyUrl' => add_query_arg('wc-api', 'WC_Gateway_PayU', home_url('/')),
        'customerIp' => getIP(),
        'merchantPosId' => OpenPayU_Configuration::getMerchantPosId(),
        'description' => get_bloginfo('name') . ' #trawallet_payment',
        'currencyCode' => get_woocommerce_currency(),
        'totalAmount' => $amount,
        'extOrderId' => uniqid(time() . '_', true),
        'products' => array(
            array(
                'name' => get_bloginfo('name') . ' #trawallet_payment',
                'unitPrice' => $amount,
                'quantity' => 1
            )
        ),
        'buyer' => array(
            'email' => $current_user->user_email,
            'phone' => '',
            'firstName' => $current_user->user_firstname,
            'lastName' => $current_user->user_lastname,
            'language' => getLanguage()
        )
    );

    try {
        $response = OpenPayU_Order::create($orderData);

        if ($response->getStatus() === OpenPayU_Order::SUCCESS) {

            // $order->update_status( 'on-hold', __( 'Awaiting PayU payment.', 'payu' ) );

            // add_post_meta($order_id, '_transaction_id', $response->getResponse()->orderId, true);
            return array(
                'result' => 'success',
                'redirect' => $response->getResponse()->redirectUri
            );
        } else {
            wc_add_notice(__('Payment error. Status code: ', 'payu') . $response->getStatus(), 'error');
            return false;
        }
    } catch (OpenPayU_Exception $e) {
        wc_add_notice(__('Payment error: ', 'payu') . $e->getMessage() . ' (' . $e->getCode() . ')', 'error');
        return false;
    }
}
