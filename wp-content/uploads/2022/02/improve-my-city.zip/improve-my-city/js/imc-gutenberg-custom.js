// Delete default Gutenberg Editor sidebar panels and add our custom ones for Improve My City
wp.data.dispatch( 'core/edit-post').removeEditorPanel( 'featured-image' );
